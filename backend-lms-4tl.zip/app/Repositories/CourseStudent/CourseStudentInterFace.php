<?php

namespace App\Repositories\CourseStudent;

interface CourseStudentInterface {
    public function addNew($data);
}