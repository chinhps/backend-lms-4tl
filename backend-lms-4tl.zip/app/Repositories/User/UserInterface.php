<?php

namespace App\Repositories\User;

interface UserInterface {
    public function infoMe();
    public function getList();
}