<table>
    <tbody>
        <tr>
            <td class="s0"></td>
            <td colspan="2" rowspan="5" style="width: 210px; height: 30px">
                <img src="<?php echo e(public_path() . '/logo.png'); ?>"
                    style="width: 200px; object-fit: scale-down; object-position: center center" />
            </td>
            <td class="s0"></td>
            <td class="s0"></td>
            <td class="s0"></td>
            <td class="s0"></td>
            <td class="s0"></td>
            <td class="s0"></td>
            <td class="s0"></td>
            <td class="s0"></td>
            <td class="s0"></td>
        </tr>
        <tr style="height: 20px">
            <td class="s0"></td>
            <td style="font-weight: bold; font-size: 30px" colspan="7" rowspan="3">
                BẢNG ĐIỂM <?php echo e($class); ?>

            </td>
            <td class="s0"></td>
            <td class="s0"></td>
        </tr>
        <tr style="height: 20px">
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr style="height: 20px">
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr style="height: 20px">
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr style="height: 20px">
            <td class="s3"></td>
            <td class="s3"></td>
            <td class="s3"></td>
            <td class="s3"></td>
            <td class="s3"></td>
            <td class="s3"></td>
            <td class="s3"></td>
            <td class="s3"></td>
            <td class="s3"></td>
            <td class="s3"></td>
            <td class="s3"></td>
            <td class="s3"></td>
        </tr>
        <tr>
            <td style="text-align: center; background-color: #dcf0ff;">STT</td>
            <td style="text-align: center; width: 100px; background-color: #dcf0ff;">Mã sinh viên</td>
            <td style="text-align: center; width: 200px; background-color: #dcf0ff;">Tên sinh viên</td>
            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td style="text-align: center; width: 100px; background-color: #dcf0ff;"><?php echo e($title->name); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <?php if(isset($students['quizs'])): ?>
            <?php $__currentLoopData = $students['quizs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="height: 20px">
                    <td style="text-align: center"><?php echo e($key + 1); ?></td>
                    <td style="text-align: center"><?php echo e($student['user']->user_code); ?></td>
                    <td style="text-align: center"><?php echo e($student['user']->name); ?></td>
                    <?php $__currentLoopData = $student['points']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td style="text-align: center">
                            <?php echo e(count($point) == 0 ? 'NULL' : $point[0]->point); ?>

                        </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php $__currentLoopData = $students['labs'][$key]['points']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td style="text-align: center">
                                <?php echo e(count($point) == 0 ? 'NULL' : $point[0]->point); ?>

                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="height: 20px">
                    <td style="text-align: center"><?php echo e($key + 1); ?></td>
                    <td style="text-align: center"><?php echo e($student['user']->user_code); ?></td>
                    <td style="text-align: center"><?php echo e($student['user']->name); ?></td>
                    <?php $__currentLoopData = $student['points']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td style="text-align: center">
                            <?php echo e(count($point) == 0 ? 'NULL' : $point[0]->point); ?>

                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>
<?php /**PATH C:\Users\phamc\OneDrive\Documents\TotNghiep\Backend_LMS\backend-lms-4tl\resources\views/exports/ListQuizLabByCourse.blade.php ENDPATH**/ ?>