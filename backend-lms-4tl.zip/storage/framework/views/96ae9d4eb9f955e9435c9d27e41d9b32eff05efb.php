<table>
    <tr>
        <th colspan="5">BẢNG ĐIỂM <?php echo e($class); ?></th>
    </tr>
    <tr>
        <th>STT</th>
        <th>Mã sinh viên</th>
        <th>Tên sinh viên</th>
        <?php $__currentLoopData = $list_quiz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($title->name); ?></th>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key); ?></td>
            <td><?php echo e($student['user']->user_code); ?></td>
            <td><?php echo e($student['user']->name); ?></td>
            <?php $__currentLoopData = $student['points']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e(count($point) == 0 ? "NULL" : $point[0]->point); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\Users\phamc\OneDrive\Documents\TotNghiep\Backend_LMS\backend-lms-4tl\resources\views/exports/quizByCourse.blade.php ENDPATH**/ ?>